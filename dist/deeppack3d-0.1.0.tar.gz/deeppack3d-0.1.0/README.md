# DeepPack3D
DeepPack3D is a Python-based 3D bin-packing software optimized for robotic palletization systems. It supports various methods, including reinforcement learning (RL) and heuristic baselines, and provides flexible options for data input and visualization.

## Features
- Supports multiple methods: RL, Best Lookahead (BL), Best Area Fit (BAF), Best Shortest Side Fit (BSSF), and Best Longest Side Fit (BLSF).
- Provides options for data generation, user input, or loading from a file.
- Offers training and testing modes for RL.
- Includes visualization to monitor the packing process.
- GPU-enabled for accelerated RL training and inference.

## Installation

## Usage
### Command-Line Interface
You can run DeepPack3D directly from the command line:
> python deeppack3d.py <method> <lookahead> [options]